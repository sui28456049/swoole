<?php

return [
    'host' => 'http://html.sadprincess.com:9501',
];