<?php

return [
	'success' => 1,
	'error' => 0,
];


?>