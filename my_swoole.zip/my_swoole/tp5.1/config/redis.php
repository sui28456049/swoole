<?php

return [
	'host' => '127.0.0.1',
	'port' => 6379,
	'out_time' => 120,
	'timeOut' => 5, // 超时时间
	'live_game_key' => 'live_game_key',
];