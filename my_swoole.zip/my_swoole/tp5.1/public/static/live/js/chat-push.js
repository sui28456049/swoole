$(function() {
	$('#discuss-box').keydown(function(event) {
	if (event.keyCode ==13) { //回车事件
		var text = $(this).val();
		var url = "http://html.sadprincess.com:9501/?s=index/chat/index";
		var data = {'content':text,'game_id':1};

		$.post(url,data, function(result) {
			$(this).val("");
		},'json');
	}
	
	});

});