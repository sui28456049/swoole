   var wsUrl = "ws://html.sadprincess.com:8812";

        var websocket = new WebSocket(wsUrl);

        //实例对象的onopen属性
        websocket.onopen = function(evt) {
           // websocket.send('666');
            console.log("conected-swoole-success");
        }

        websocket.onmessage = function(evt) {
            push(evt.data);
           //console.log("ws-server-return-data:" + evt.data); //服务器推送过来的消息
        }

        //onclose
        websocket.onclose = function(evt) {
        }
        //onerror

        websocket.onerror = function(evt, e) {
            console.log("error:" + evt.data);
        }

        function push(data) {
        	//var data = eval('(' + data + ')'); //字符串转为json
        	data = JSON.parse(data);
        	console.log(data);
        	html =  '<div class="comment">'
            html += '<span>' + data.user + '</span>'
            html += '<span>' + data.content + '</span>'
            html += '</div>';

			$('#comments').prepend(html);
        }